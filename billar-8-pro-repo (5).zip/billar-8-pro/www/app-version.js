/* El workflow reemplaza este archivo en cada build */
window.B8_APP_VERSION = { code: 0, name: "dev", jsonUrl: "" };
