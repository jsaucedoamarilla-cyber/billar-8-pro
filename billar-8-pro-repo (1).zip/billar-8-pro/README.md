# Billar 8 Pro

Juego de billar (web + app Android con Capacitor 6).

## Estructura
- `www/` — el juego (index.html, firebase-config.js, iconos, tacos, PWA)
- `capacitor.config.json`, `package.json` — configuración de la app
- `google-services.json` — **ya lo tenés en tu repo, dejalo en la raíz** (package_name `com.billar8pro.app`)
- `.github/workflows/build-apk.yml` — compila el APK y lo prueba en un emulador
- `scripts/smoke-test.sh` — abre la app y guarda el log si se cierra

## Cómo usarlo
1. Subí todo esto a la raíz del repo (borrá los zips y carpetas viejas).
2. Pestaña **Actions** → "Build APK y prueba de arranque" → *Run workflow*.
3. Al terminar, en **Artifacts** bajá `billar-8-pro-apk` (el APK).
4. Si la app se cierra en la prueba, bajá `smoke-test-logs` y buscá `FATAL EXCEPTION` en `logcat.txt`.

## Login con Google
En Firebase agregá la huella SHA-1 del APK (Project settings → tu app Android).
Para APK debug, la SHA-1 sale de `keytool -list -v -keystore ~/.android/debug.keystore`.

## Si la app se cierra
Entrá al run en **Actions → Summary**: el error (FATAL EXCEPTION) aparece escrito arriba, listo para copiar.
Borrá del repo el workflow viejo `diagnosticar-cierre.yml` y `build-apk.sh` para que no corran en paralelo.
