#!/usr/bin/env bash
# Instala el APK, lo abre y revisa si el proceso sigue vivo.
# Guarda logcat y captura, y escribe el error en el Summary del run.
PKG=com.billar8pro.app
S="${GITHUB_STEP_SUMMARY:-/dev/null}"

adb install -r apk/app-debug.apk || { echo "## ❌ No se pudo instalar el APK" >> "$S"; exit 1; }
adb logcat -c
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1
sleep 25
adb logcat -d > logcat.txt
adb exec-out screencap -p > screen.png || true

if adb shell pidof "$PKG" >/dev/null; then
  echo "## ✅ La app sigue abierta después de 25 s" >> "$S"
  exit 0
fi

{
  echo "## ❌ La app se cerró"
  echo "### FATAL EXCEPTION"
  echo '```'
  grep -A 30 "FATAL EXCEPTION" logcat.txt | head -60
  echo '```'
  echo "### Otros errores de la app"
  echo '```'
  grep -E "AndroidRuntime|Capacitor|FirebaseApp|chromium.*(Uncaught|ERROR)|$PKG.*(Died|crash)|Process $PKG" logcat.txt | head -40
  echo '```'
} >> "$S"
cat "$S" 2>/dev/null | head -80
exit 1
