# Billar 8 Pro

Juego de billar (web + app Android con Capacitor 6).

## Estructura
- `www/` — el juego (index.html, firebase-config.js, iconos, tacos, PWA)
- `capacitor.config.json`, `package.json` — configuración de la app
- `.github/workflows/build-apk.yml` — compila el APK y lo prueba en un emulador
- `scripts/smoke-test.sh` — abre la app y guarda el log si se cierra

## Cómo usarlo
1. Subí todo esto a la raíz del repo (borrá los zips y carpetas viejas).
2. Pestaña **Actions** → "Build APK y prueba de arranque" → *Run workflow*.
3. Al terminar, en **Artifacts** bajá `billar-8-pro-apk` (el APK).
4. Si la app se cierra en la prueba, bajá `smoke-test-logs` y buscá `FATAL EXCEPTION` en `logcat.txt`.

## Login con Google
Esta versión **no incluye el login nativo de Firebase/Google** (causaba el cierre al abrir). En la app se entra como invitado; el login con Google sigue funcionando en la versión web.

## Si la app se cierra
Entrá al run en **Actions → Summary**: el error (FATAL EXCEPTION) aparece escrito arriba, listo para copiar.
Borrá del repo el workflow viejo `diagnosticar-cierre.yml` y `build-apk.sh` para que no corran en paralelo.

## Actualizar la app para los usuarios
Cada vez que subís cambios a `main`, el workflow:
1. compila el APK con un `versionCode` mayor (100 + número de run) y la misma firma (`debug.keystore`),
2. crea un *Release* con el APK, y
3. actualiza `version.json` en el repo.

Al abrir la app (con internet), el juego lee `version.json`. Si hay una versión más nueva muestra el aviso
"Hay una versión nueva… Descargar", que abre la página de descarga.

Requisitos:
- Dejá tu `debug.keystore` (el de `guia-25`) en la raíz del repo. Si cambia la firma, nadie puede actualizar encima.
- El repo debe ser **público** para que los usuarios lean `version.json` y bajen el APK del Release.
  Si es privado, hospedá el APK donde quieras (Drive, etc.) y creá en GitHub una variable
  *Settings → Secrets and variables → Actions → Variables* llamada `UPDATE_PAGE_URL` con ese link (solo funciona el
  aviso si `version.json` es accesible públicamente).
- Quien tenga la `guia-21` (otra firma) debe desinstalarla una vez. Desde la `guia-25` en adelante se instala encima.
- La primera vez, los que ya tienen la app instalada no tienen el aviso: instalá a mano este APK nuevo y de ahí en adelante les avisa.
