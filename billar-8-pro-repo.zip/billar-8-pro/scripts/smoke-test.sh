#!/usr/bin/env bash
# Instala el APK, lo abre y revisa si el proceso sigue vivo. Guarda logcat y captura.
PKG=com.billar8pro.app
adb install -r apk/app-debug.apk || exit 1
adb logcat -c
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1
sleep 25
adb logcat -d > logcat.txt
adb exec-out screencap -p > screen.png || true
if adb shell pidof "$PKG" >/dev/null; then
  echo "OK: la app sigue abierta"
else
  echo "FALLO: la app se cerró. Mirá logcat.txt (buscá FATAL EXCEPTION)"
  grep -A 25 "FATAL EXCEPTION" logcat.txt | head -60
  exit 1
fi
