# Billar 8 Pro

Juego de billar (web + app Android con Capacitor 6).

## Estructura
- `www/` — el juego (index.html, firebase-config.js, iconos, tacos, PWA)
- `capacitor.config.json`, `package.json` — configuración de la app
- `.github/workflows/build-apk.yml` — compila el APK y lo prueba en un emulador
- `scripts/smoke-test.sh` — abre la app y guarda el log si se cierra

## Cómo usarlo
1. Subí todo esto a la raíz del repo (borrá los zips y carpetas viejas).
2. Pestaña **Actions** → "Build APK y prueba de arranque" → *Run workflow*.
3. Al terminar, en **Artifacts** bajá `billar-8-pro-apk` (el APK).
4. Si la app se cierra en la prueba, bajá `smoke-test-logs` y buscá `FATAL EXCEPTION` en `logcat.txt`.

## Login con Google
Esta versión **no incluye el login nativo de Firebase/Google** (causaba el cierre al abrir). En la app se entra como invitado; el login con Google sigue funcionando en la versión web.

## Si la app se cierra
Entrá al run en **Actions → Summary**: el error (FATAL EXCEPTION) aparece escrito arriba, listo para copiar.
Borrá del repo el workflow viejo `diagnosticar-cierre.yml` y `build-apk.sh` para que no corran en paralelo.

## Actualizar la app para los usuarios
Cada vez que subís cambios a `main`, el workflow:
1. compila el APK con un `versionCode` mayor (100 + número de run) y la misma firma (`debug.keystore`),
2. crea un *Release* con el APK, y
3. actualiza `version.json` en el repo.

Al abrir la app (con internet), el juego lee `version.json`. Si hay una versión más nueva muestra el aviso
"Hay una versión nueva… Descargar", que abre la página de descarga.

Requisitos:
- Dejá tu `debug.keystore` (el de `guia-25`) en la raíz del repo. Si cambia la firma, nadie puede actualizar encima.
- El repo debe ser **público** para que los usuarios lean `version.json` y bajen el APK del Release.
  Si es privado, hospedá el APK donde quieras (Drive, etc.) y creá en GitHub una variable
  *Settings → Secrets and variables → Actions → Variables* llamada `UPDATE_PAGE_URL` con ese link (solo funciona el
  aviso si `version.json` es accesible públicamente).
- Quien tenga la `guia-21` (otra firma) debe desinstalarla una vez. Desde la `guia-25` en adelante se instala encima.
- La primera vez, los que ya tienen la app instalada no tienen el aviso: instalá a mano este APK nuevo y de ahí en adelante les avisa.

## Monedas y niveles
- **Respaldo automático:** la primera vez que el jugador tiene internet, el juego crea un código de 8 caracteres,
  sube el progreso (monedas, nivel, tacos) a Firestore y se lo muestra para anotar. Después se actualiza solo al
  terminar cada partida. Con el código se recupera en otro celular: Perfil → Respaldo.
  (Requiere que las reglas de Firestore permitan la colección `respaldo`.)
- **Niveles 1 a 1000 (curva de ~2 años):** XP para subir de nivel = 40 + 1 cada 10 niveles. Nivel 1000 = 89.460 XP.
  Ganar suma 20 XP y perder resta 8 XP (nunca baja del inicio del nivel actual: no se pierden niveles).
  Con 20 partidas por día, ganando el 50% se llega en unos 2 años; ganando el 70%, en poco más de 1 año.
- **Jugadores actuales:** conservan el nivel que ya tenían (se convierte su XP una sola vez).
- **Premio por nivel:** 20 monedas por nivel, +300 cada 10 niveles y +2.000 cada 100.

## Ruleta
- **1 giro gratis cada 24 horas.** Después se puede girar las veces que quieran **pagando 400 🪙 por giro**
  (si no alcanzan las monedas, avisa). Se usa el reloj del celular para las 24 h.
- El cobro, el premio y la hora del giro se guardan antes de animar la rueda: si cierran la app a mitad no se pierde nada.
- **Monedas x2:** 50, 100, 200, 400, 1000 y 2000 🪙 (antes 25, 50, 100, 200, 500 y 1000). Los diamantes (1 y 2 💎) quedaron igual.
  Valor esperado por giro: unas 346 monedas, por eso el giro pagado cuesta 400 (en promedio se pierden ~54 🪙) y no regala monedas.
  Para cambiar el precio: constante `WHEEL_COST` en `www/index.html`.
- **Diseño nuevo:** aro dorado con luces, colores con degradé, puntero rojo y centro dorado (todo en SVG, sin imágenes).
